//
//  UINavgationBar+Custom.h
//  REducation
//
//  Created by changxm on 14-3-22.
//  Copyright (c) 2014年 changxm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationBar (Customized)


-(void)loadNavigationBar;

@end
