//
//  ViewController.h
//  vh264enc
//
//  Created by YangXu on 2018/1/17.
//  Copyright © 2018年 OIT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, copy)NSString *phoneNum;
@property (nonatomic, copy)NSString *workNum;
@property (nonatomic, copy)NSString *lbsNum;

@end

